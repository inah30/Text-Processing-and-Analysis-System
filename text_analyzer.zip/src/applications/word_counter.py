from collections import Counter

class WordCounter:
    def __init__(self):
        self.word_counts = Counter()

    def count_words(self, file_path):
        try:
            with open(file_path, 'r') as file:
                content = file.read().lower()
                words = content.split()
                self.word_counts.update(words)

            unique_words = len(self.word_counts)
            top_words = self.word_counts.most_common(5)
            return {"unique_words": unique_words, "top_words": top_words}
        except FileNotFoundError:
            return {"error": "File not found"}
