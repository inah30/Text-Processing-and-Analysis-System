from src.data_structures.stack import Stack

class TextParser:
    def __init__(self):
        self.stack = Stack()

    def analyze(self, file_path):
        try:
            with open(file_path, 'r') as file:
                content = file.readlines()

            line_count = len(content)
            balanced = self.check_balance(content)
            return {"balanced": balanced, "line_count": line_count}
        except FileNotFoundError:
            return {"error": "File not found"}

    def check_balance(self, lines):
        for line in lines:
            for char in line:
                if char in "({[":
                    self.stack.push(char)
                elif char in ")}]":
                    if self.stack.is_empty() or not self.matches(self.stack.pop(), char):
                        return False
        return self.stack.is_empty()

    def matches(self, open, close):
        pairs = {')': '(', '}': '{', ']': '['}
        return pairs[close] == open
