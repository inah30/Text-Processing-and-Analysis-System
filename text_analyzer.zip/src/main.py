from src.data_structures.stack import Stack
from src.data_structures.queue import Queue
from src.applications.parser import TextParser
from src.applications.word_counter import WordCounter

if __name__ == "__main__":
    # Demonstrating Stack Functionality
    print("=== Stack Demonstration ===")
    stack = Stack()
    stack.push(10)
    stack.push(20)
    stack.push(30)
    stack.push(50)
    if stack.is_empty():
        print("Stack is empty")
    else:
        print("Stack Size:", stack.size())
        print("Top Element:", stack.peek())
        print("Pop:", stack.pop())
        print("Is Empty:", stack.is_empty())


    # Demonstrating Queue Functionality
    print("\n=== Queue Demonstration ===")
    queue = Queue()
    queue.enqueue(10)
    queue.enqueue(20)
    queue.enqueue(30)
    queue.enqueue(30)
    queue.enqueue(50)
    if queue.is_empty():
        print("Queue is empty")
    else:
        print("Queue Size:", queue.size())
        print("Dequeue:", queue.dequeue())
        print("Is Empty:", queue.is_empty())
    

    # Text Parsing Application
    print("\n=== Text Parsing ===")
    parser = TextParser()
    parser_result = parser.analyze("src/sample.txt")
    print("Parser Result:", parser_result)

    # Word Counting Application
    print("\n=== Word Counting ===")
    counter = WordCounter()
    counter_result = counter.count_words("src/sample.txt")
    print("Word Count Result:", counter_result)
