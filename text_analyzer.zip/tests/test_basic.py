import unittest
from src.data_structures.stack import Stack
from src.applications.parser import TextParser

class TestStack(unittest.TestCase):
    def test_stack_basic(self):
        stack = Stack()
        self.assertTrue(stack.is_empty())
        stack.push(1)
        self.assertFalse(stack.is_empty())
        self.assertEqual(stack.peek(), 1)
        self.assertEqual(stack.pop(), 1)
        self.assertTrue(stack.is_empty())

class TestTextParser(unittest.TestCase):
    def test_text_parser(self):
        parser = TextParser()
        result = parser.analyze("src/sample.txt")
        self.assertIn("balanced", result)
        self.assertIn("line_count", result)

if __name__ == "__main__":
    unittest.main()
