# Text Processing and Analysis System

## Overview
The Text Processing and Analysis System is a Python-based project that demonstrates text processing using basic data structures. It includes:
1. **Text Parsing**: Checks for balanced parentheses/brackets and counts lines.
2. **Word Counting**: Counts the frequency of words in a text file and provides basic statistics.

## Features
- **Stack Implementation**:
  - Supports `push`, `pop`, and `peek` operations.
  - Tracks size and checks if empty.
- **Queue Implementation**:
  - Supports `enqueue` and `dequeue` operations.
  - Tracks size and checks if empty.
- **Applications**:
  - Text parser to check balanced brackets and count lines.
  - Word frequency counter with top-word statistics.

## Project Structure
```
text_analyzer/
├── src/
│   ├── data_structures/
│   │   ├── stack.py          # Stack implementation
│   │   └── queue.py          # Queue implementation
│   ├── applications/
│   │   ├── parser.py         # Text parser using Stack
│   │   └── word_counter.py   # Word counter application
│   ├── main.py               # Entry point of the application
│   └── sample.txt            # Sample text file for testing
├── tests/
│   └── test_basic.py         # Unit tests for the project
└── README.md                 # Project documentation
```

## Setup Guide

### 1. Prerequisites
- **Python 3.8+**: Install Python if not already installed. You can download it from [python.org](https://www.python.org/).

### 2. Installation
1. Download the project zip:
   Navigate to the project directory:
   ```bash
   cd text_analyzer
   ```

2. Verify Directory Structure:
   Ensure the directory structure matches the one provided above.

3. (Optional) Set Up a Virtual Environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Linux/Mac
   venv\Scriptsctivate     # On Windows
   ```

## How to Run

### 1. Run the Main Application
1. Navigate to the `text_analyzer` directory:
   ```bash
   cd text_analyzer
   ```
2. Execute the program:
   ```bash
   python src/main.py
   ```

### 2. Run Unit Tests
1. Run tests using `unittest`:
   ```bash
   python -m unittest discover -s tests -p "*.py"
   ```

## Sample Outputs

### Main Application:
```
Parser Result: {'balanced': True, 'line_count': 3}
Word Count Result: {'unique_words': 10, 'top_words': [('the', 2), ('is', 2)]}
```

### Unit Tests:
```
..
----------------------------------------------------------------------
Ran 2 tests in 0.001s

OK
```
